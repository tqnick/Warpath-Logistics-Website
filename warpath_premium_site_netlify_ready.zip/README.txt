WARPATH LOGISTICS PREMIUM SITE

Files included:
- index.html
- services.html
- equipment.html
- quote.html
- about.html
- contact.html
- css/styles.css
- js/main.js
- assets/warpath-logo.jpg
- assets/warpath-logo-square.png
- assets/hero-bg.svg

How to deploy to Netlify:
1. Unzip this folder on your computer.
2. Drag the unzipped folder contents into Netlify, or drag the whole folder if Netlify accepts it.
3. Open the live URL.
4. Replace placeholder phone number and email if needed.
5. Connect your GoDaddy domain once you are satisfied.

Notes:
- The quote form is set up with Netlify form attributes.
- Replace "(210) XXX-XXXX" with your final dispatch number.
- Replace dispatch email if needed.
